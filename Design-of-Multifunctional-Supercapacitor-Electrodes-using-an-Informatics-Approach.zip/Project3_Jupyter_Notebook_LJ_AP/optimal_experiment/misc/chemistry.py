#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 09:06:53 2017

@author: rarroyave
"""

from pymatgen.core.composition import Composition
#from pyEQL import chemical_formula
import hyperspy.misc.material as material

    

class Chemical_Composition(dict):
    """
    The Chemical_Composition() class implements a series of methods and 
    attributes that transform different types of ways of representing
    a chemical composition into a unified chemistry formula. In addition, an 
    instance of this class results in a dictionary of different representations
    of the composition that may be useful in materials informatics problems.
    """
    def __init__(self,formula,atomic=True,*args,**kwargs):
       
        """
          When initializing an instance of Chemical_Composition class, the
          arg formula is first analyzed to try and understand the way in which 
          the chemical formula has been represented. \\
        """
        dict.__init__(self,args)
        
        try:
           c=Composition(formula)
        except:
           return None 
        self['nelements']=c.to_data_dict['nelements']
        self['elements']=[k for k in c.as_dict().keys()]
        if atomic == True:
            self['atomic_formula']=[c.to_data_dict['unit_cell_composition'][k] \
                      for k in c.to_data_dict['unit_cell_composition'].keys()]
            self['atomic_fraction']=[c.get_atomic_fraction(k) \
                             for k in self['elements']]
            self['weight_fraction']=[c.get_wt_fraction(k)  \
                             for k in self['elements']]       
        else:
            self['weight_formula']=[c.to_data_dict['unit_cell_composition'][k] \
                      for k in c.to_data_dict['unit_cell_composition'].keys()]
            self['weight_fraction']=self['weight_formula']/float(sum(self['weight_formula']))
            self['atomic_fraction']=list(material.weight_to_atomic(self['weight_fraction'],self['elements']))
            
        
    
    
          
         
          
          
          
          
      
          
    