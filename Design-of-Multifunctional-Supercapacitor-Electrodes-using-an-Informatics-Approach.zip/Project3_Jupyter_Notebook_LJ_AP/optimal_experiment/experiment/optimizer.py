#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  2 08:20:57 2017

@author: rarroyave
taken from optimizer.py from skopt library
"""

import warnings
from collections import Iterable
from numbers import Number
import random

import numpy as np

from scipy.optimize import fmin_l_bfgs_b

from sklearn.base import clone
from sklearn.base import is_regressor
from sklearn.externals.joblib import Parallel, delayed
from sklearn.utils import check_random_state

from skopt.acquisition import _gaussian_acquisition
from skopt.acquisition import gaussian_acquisition_1D
from skopt.space import Categorical
from skopt.space import Space
from skopt.utils import create_result

from skopt.learning.gaussian_process.kernels import ConstantKernel
from skopt.learning.gaussian_process.kernels import HammingKernel
from skopt.learning.gaussian_process.kernels import Matern
from skopt.space import check_dimension

from skopt.learning import ExtraTreesRegressor
from skopt.learning import GaussianProcessRegressor
from skopt.learning import RandomForestRegressor




class Optimizer(object):
    """Run bayesian optimisation loop.
    An `Optimizer` represents the steps of a bayesian optimisation loop. To
    use it you need to provide your own loop mechanism. The various
    optimisers provided by `skopt` use this class under the hood.
    Use this class directly if you want to control the iterations of your
    bayesian optimisation loop.
    Parameters
    ----------
    * `experimental_space`: instance of Experimental Space
    * `base_estimator_key` [sklearn regressor]:
        Accepts keywords gpr and etr standing for GaussianProcessRegressor and
        EstraTreeRegressor.
        Should inherit from `sklearn.base.RegressorMixin`.
        In addition the `predict` method, should have an optional `return_std`
        argument, which returns `std(Y | x)`` along with `E[Y | x]`.
    * `n_random_starts` [int, default=10]:
        Number of evaluations of `func` with random initialization points
        before approximating the `func` with `base_estimator`. While random
        points are being suggested no model will be fit to the observations.
    * `acq_func` [string, default=`"EI"`]:
        Function to minimize over the posterior distribution. Can be either
        - `"LCB"` for lower confidence bound.
        - `"EI"` for negative expected improvement.
        - `"PI"` for negative probability of improvement.
        - `"gp_hedge"` Probabilistically choose one of the above three
          acquisition functions at every iteration.
            - The gains `g_i` are initialized to zero.
            - At every iteration,
                - Each acquisition function is optimised independently to
                  propose an candidate point `X_i`.
                - Out of all these candidate points, the next point `X_best` is
                  chosen by $softmax(\eta g_i)$
                - After fitting the surrogate model with `(X_best, y_best)`,
                  the gains are updated such that $g_i -= \mu(X_i)$
    * `acq_optimizer` [string, `"sampling"` or `"lbfgs"`, default=`"lbfgs"`]:
        Method to minimize the acquistion function. The fit model
        is updated with the optimal value obtained by optimizing `acq_func`
        with `acq_optimizer`.
        - If set to `"sampling"`, then `acq_func` is optimized by computing
          `acq_func` at `n_points` sampled randomly.
        - If set to `"lbfgs"`, then `acq_func` is optimized by
              - Sampling `n_restarts_optimizer` points randomly.
              - `"lbfgs"` is run for 20 iterations with these points as initial
                points to find local minima.
              - The optimal of these local minima is used to update the prior.
    * `random_state` [int, RandomState instance, or None (default)]:
        Set random state to something other than None for reproducible
        results.
    * `acq_func_kwargs` [dict]:
        Additional arguments to be passed to the acquistion function.
    * `acq_optimizer_kwargs` [dict]:
        Additional arguments to be passed to the acquistion optimizer.
    Attributes
    ----------
    * `Xi` [list]:
        Points at which objective has been evaluated.
    * `yi` [scalar]:
        Values of objective at corresponding points in `Xi`.
    * `models` [list]:
        Regression models used to fit observations and compute acquisition
        function.
    * `space`
        An instance of `skopt.space.Space`. Stores parameter search space used
        to sample points, bounds, and type of parameters.
    """
    def __init__(self, experimental_space, observable,base_estimator,
                 n_random_starts=10, acq_func="gp_hedge",
                 acq_optimizer="lbfgs",throughput=1,limit_samples=True,
                 random_state=None, acq_func_kwargs=None,
                 acq_optimizer_kwargs=None):
        # Arguments that are just stored not checked
        
        
        self.limit_samples = limit_samples
        self.throughput=int(throughput)
        if self.throughput > 1:
           self.acq_optimizer = "sampling"
        self.observable=observable
        self.experimental_space=experimental_space
        dimensions=self.experimental_space['dimensions']
        self.acq_func = acq_func
        self.rng = check_random_state(random_state)
        if acq_func_kwargs is None:
           acq_func_kwargs = {"xi": 0.01, "kappa": 1.96} 
        self.acq_func_kwargs = acq_func_kwargs

        if self.acq_func == "gp_hedge":
            self.cand_acq_funcs_ = ["EI", "LCB", "PI"]
            self.gains_ = np.zeros(3)
        else:
            self.cand_acq_funcs_ = [self.acq_func]

        if acq_func_kwargs is None:
            acq_func_kwargs = dict()
        self.eta = acq_func_kwargs.get("eta", 1.0)

        if acq_optimizer_kwargs is None:
            acq_optimizer_kwargs = dict()

        self.n_points = acq_optimizer_kwargs.get("n_points", 10000)
        self.n_restarts_optimizer = acq_optimizer_kwargs.get(
            "n_restarts_optimizer", 5)
        
        n_jobs = acq_optimizer_kwargs.get("n_jobs", 1)
        self.n_jobs = n_jobs

        self.space = self.experimental_space['space']
        self.models = []
        self.Xi = []
        self.yi = []
        self.X = []

        self._cat_inds = []
        self._non_cat_inds = []
        for ind, dim in enumerate(self.space.dimensions):
            if isinstance(dim, Categorical):
                self._cat_inds.append(ind)
            else:
                self._non_cat_inds.append(ind)
                
        if isinstance(base_estimator, str):
           if base_estimator not in ("RF", "ET","GP"):
                raise ValueError(
                "Valid strings for the base_estimator parameter"
                " are: 'RF' or 'ET', not '%s'" % base_estimator)  
           else:     
                base_estimator = self._generate_base_estimator(base_estimator)  
                
        self._check_arguments(base_estimator, n_random_starts, acq_optimizer)

       
        
    def _generate_base_estimator(self,base_estimator):         
        
        if  base_estimator == "GP":
            return self._generate_gaussian_process_regressor()
        elif  base_estimator == "RF":  
            return self._generate_random_forest_regressor()
        elif base_estimator == "ET":
            return self._generate_extra_tree_regressor()
    
    def _generate_random_forest_regressor(self):
        rng = check_random_state(1234)

        base_estimator = RandomForestRegressor(n_estimators=100,
                                                   min_samples_leaf=3,
                                                   n_jobs=self.n_jobs,
                                                   random_state=rng) 
        return base_estimator
        
    def _generate_extra_tree_regressor(self):
        rng = check_random_state(1234)
        base_estimator = ExtraTreesRegressor(n_estimators=100,
                                                 min_samples_leaf=3,
                                                 n_jobs=self.n_jobs,
                                                 random_state=rng)
        return base_estimator
        
    def _generate_gaussian_process_regressor(self):
        """ 
        The Gaussian process estimator to use for optimization.
        By default, a Matern kernel is used with the following
        hyperparameters tuned.
        - All the length scales of the Matern kernel.
        - The covariance amplitude that each element is multiplied with.
        - Noise that is added to the matern kernel. The noise is assumed
          to be iid gaussian.
        """  
        rng = check_random_state(1234)
        dimensions = self.experimental_space['dimensions']
        dim_types = [check_dimension(d) for d in dimensions]
        is_cat = all([isinstance(check_dimension(d), Categorical) for d in dim_types])
        if is_cat:
           transformed_dims = [check_dimension(d,
                                      transform="identity") for d in dimensions]
        else:
            transformed_dims = []
            for dim_type, dim in zip(dim_types, dimensions):
                if isinstance(dim_type, Categorical):
                   transformed_dims.append(check_dimension(dim, transform="onehot"))
                   # To make sure that GP operates in the [0, 1] space
                else:
                   transformed_dims.append(check_dimension(dim, transform="normalize"))
        space = Space(transformed_dims)
        base_estimator=None

        if base_estimator is None:
           cov_amplitude = ConstantKernel(1.0, (0.01, 1000.0))

           if is_cat:
              other_kernel = HammingKernel(
                length_scale=np.ones(space.transformed_n_dims))
              self.acq_optimizer = "sampling"
           else:
              other_kernel = Matern(
                length_scale=np.ones(space.transformed_n_dims),
                length_scale_bounds=[(0.01, 100)] * space.transformed_n_dims,
                nu=2.5)
        noise="gaussian"

        base_estimator = GaussianProcessRegressor(
             kernel=cov_amplitude * other_kernel,
             normalize_y=True, random_state=rng, alpha=0.0, noise=noise, n_restarts_optimizer=2)

        return base_estimator
            

    def _check_arguments(self, base_estimator, n_random_starts, acq_optimizer):
        """Check arguments for sanity."""
        if not is_regressor(base_estimator):
            raise ValueError(
                "%s has to be a regressor." % base_estimator)
        self.base_estimator = base_estimator

        if n_random_starts < 0:
            raise ValueError(
                "Expected `n_random_starts` >= 0, got %d" % n_random_starts)
        self._n_random_starts = n_random_starts

        if acq_optimizer == "auto":
            warnings.warn("The 'auto' option for the acq_optimizer will be "
                          "removed in 0.4.")
            acq_optimizer = "lbfgs"
        self.acq_optimizer = acq_optimizer
        if self.acq_optimizer not in ["lbfgs", "sampling"]:
            raise ValueError(
                "Expected acq_optimizer to be 'lbfgs' or 'sampling', "
                "got %s" % acq_optimizer)

    def ask(self):
        """Suggest next point at which to evaluate the objective.
        Returns a random point for the first `n_random_starts` calls, after
        that `base_estimator` is used to determine the next point.
        """
        if self._n_random_starts > 0:
            self._n_random_starts -= 1
            # this will not make a copy of `self.rng` and hence keep advancing
            # our random state.
            # pick random sample in experimental space
                
            random_id = random.sample(self.experimental_space['samples'],1)[0]['id']    
            index     = self.experimental_space.find_sample_by_id(random_id)  
            self.experimental_space['samples'][index]['observables'][self.observable]['to_measure']=True
            self.experimental_space.update(observable=self.observable)
            sample_ids=self.experimental_space.get_samples_to_measure(self.observable)
            return sample_ids
       

        else:
            if not self.models:
                raise ValueError("Random evaluations exhausted and no "
                                 "model has been fit.")

            cat_inds = self._cat_inds
            non_cat_inds = self._non_cat_inds
            next_x = self._next_x

            if len(cat_inds) == 0:
                close_to_next_x = lambda x: np.allclose(x, next_x)
                if np.any(np.apply_along_axis(close_to_next_x, 1, self.Xi)):
                    warnings.warn("The objective has been evaluated "
                                  "at this point before.")
            else:
                next_x_arr = np.array(next_x)
                next_x_non_cat = np.array(
                    next_x_arr[non_cat_inds], dtype=np.float32)
                for x in self.Xi:
                    x_arr = np.array(x)
                    cat_eq = np.all(x_arr[cat_inds] == next_x_arr[cat_inds])
                    non_cat_eq = np.allclose(
                        np.array(x_arr[non_cat_inds], dtype=np.float32),
                        next_x_non_cat)
                    if cat_eq and non_cat_eq:
                        warnings.warn("The objective has been evaluated "
                                      "at this point before.")

            # return point computed from last call to tell()
            sample_ids=[]
            if all([isinstance(point,Iterable) for point in next_x]):
               
               for nx in next_x:
                   index=self.experimental_space.match_features(nx)
                   if index <0:
                      return None
                   else:
                      sample_id = self.experimental_space['samples'][index]['id']
                      sample_ids.append(sample_id) 
            else:
               index=self.experimental_space.match_features(next_x) 
               if index <0:
                  return None
               else:
                      sample_id = self.experimental_space['samples'][index]['id'] 
                      sample_ids.append(sample_id)    
            
            return sample_ids

    def tell(self, sample_ids, observable, values, fit=True):
        """Record an observation (or several) of the objective function.
        Provide values of the objective function at points suggested by `ask()`
        or other points. By default a new model will be fit to all
        observations. The new model is used to suggest the next point at
        which to evluate the objective. This point can be retrieved by calling
        `ask()`.
        To add observations without fitting a new model set `fit` to False.
        To add multiple observations in a batch pass a list-of-lists for `x`
        and a list of scalars for `y`.
        * `x` [list or list-of-lists]:
            Point at which objective was evaluated.
        * `y` [scalar or list]:
            Value of objective at `x`.
        * `fit` [bool, default=True]
            Fit a model to observed evaluations of the objective. A model will
            only be fitted after `n_random_starts` points have been queried
            irrespective of the value of `fit`.
        """
        # if y isn't a scalar it means we have been handed a batch of points
        
        self.experimental_space.measure_by_id(observable,sample_ids,values)
        
        x=self.experimental_space.get_list_of_feature_lists_by_ids(sample_ids)
        y=values
        
#        print(x)
#        print(y)

#        print([q in self.space for q in x])
        if (isinstance(y, Iterable) and all(isinstance(point, Iterable)
                                            for point in x)):
            if not np.all([p in self.space for p in x]):
                raise ValueError("Not all points are within the bounds of"
                                 " the space.")
            self.Xi.extend(x)
            self.yi.extend(y)

        elif isinstance(x, Iterable) and isinstance(y, Number):
            if x not in self.space:
                raise ValueError("Point (%s) is not within the bounds of"
                                 " the space (%s)."
                                 % (x, self.space.bounds))
            self.Xi.append(x)
            self.yi.append(y)

        else:
            raise ValueError("Type of arguments `x` (%s) and `y` (%s) "
                             "not compatible." % (type(x), type(y)))

           
#        print(self.Xi)
#        print(np.shape(self.Xi))
#        print(self.yi)
#        print(self.space)

        
        if fit and self._n_random_starts == 0:
            transformed_bounds = np.array(self.space.transformed_bounds)
            est = clone(self.base_estimator)

            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                est.fit(self.space.transform(self.Xi), self.yi)

            if hasattr(self, "next_xs_") and self.acq_func == "gp_hedge":
                self.gains_ -= est.predict(np.vstack(self.next_xs_))
            self.models.append(est)
            #print(self.models)

            #X = self.space.transform(self.space.rvs(
            #    n_samples=self.n_points, random_state=self.rng))
            
           
            if self.limit_samples:
               nsamples=min(self.n_points,len(self.experimental_space['x_umt']))
               self.X=random.sample(list(self.experimental_space['x_umt']),nsamples)
            else:   
               self.X=self.experimental_space['x_umt']
            
            
            #print(X)
            self.next_xs_ = []
            for cand_acq_func in self.cand_acq_funcs_:
                values = _gaussian_acquisition(
                    X=self.X, model=est, y_opt=np.min(self.yi),
                    acq_func=cand_acq_func,
                    acq_func_kwargs=self.acq_func_kwargs)
                # Find the minimum of the acquisition function by randomly
                # sampling points from the space
                if self.acq_optimizer == "sampling":
                    if self.throughput>1 and self.acq_func != "gp_hedge":
                       next_x = self.X[np.argsort(values)[:self.throughput]] 
                    else:    
                       next_x = self.X[np.argmin(values)]
                    
   
                # Use BFGS to find the mimimum of the acquisition function, the
                # minimization starts from `n_restarts_optimizer` different
                # points and the best minimum is used
                elif self.acq_optimizer == "lbfgs":
                    x0 = self.X[np.argsort(values)[:self.n_restarts_optimizer]]
                   #x0 = self.experimental_space['x_umt'][np.argsort(values)[:self.n_restarts_optimizer]] 
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        results = Parallel(n_jobs=self.n_jobs)(
                            delayed(fmin_l_bfgs_b)(
                                gaussian_acquisition_1D, x,
                                args=(est, np.min(self.yi), cand_acq_func,
                                      self.acq_func_kwargs),
                                bounds=self.space.transformed_bounds,
                                approx_grad=False,
                                maxiter=20)
                            for x in x0)

                    cand_xs = np.array([r[0] for r in results])
                    cand_acqs = np.array([r[1] for r in results])
                    next_x = cand_xs[np.argmin(cand_acqs)]

                # lbfgs should handle this but just in case there are
                # precision errors.
                if not self.space.is_categorical:
                    next_x = np.clip(
                        next_x, transformed_bounds[:, 0],
                        transformed_bounds[:, 1])
                if self.throughput > 1 and self.acq_func != "gp_hedge":
                   self.next_xs_.extend(next_x)
                else:    
                   self.next_xs_.append(next_x)

            if self.acq_func == "gp_hedge":
                logits = np.array(self.gains_)
                logits -= np.max(logits)
                exp_logits = np.exp(self.eta * logits)
                probs = exp_logits / np.sum(exp_logits)
                next_x = self.next_xs_[np.argmax(np.random.multinomial(1,
                                                                       probs))]
            else:
                if self.throughput > 1 and self.acq_func != "gp_hedge":
                   next_x = self.next_xs_
                else:    
                   next_x = self.next_xs_[0]
                  
                   
            if all([isinstance(point,Iterable) for point in next_x]):
               self._next_x=[]
               for nx in next_x:
                  self._next_x.append(self.space.inverse_transform(
                     nx.reshape((1, -1)))[0]) 
            else: 
                # note the need for [0] at the end
                self._next_x = self.space.inverse_transform(
                     next_x.reshape((1, -1)))[0]
            
        # Pack results
        return create_result(self.Xi, self.yi, self.space, self.rng,
                             models=self.models)

    #def run(self, func, n_iter=1):
    #    """Execute ask() + tell() `n_iter` times"""
    #    for _ in range(n_iter):
    #        x = self.ask()
    #        self.tell(x, func(x))

    #    return create_result(self.Xi, self.yi, self.space, self.rng,
    #                         models=self.models)