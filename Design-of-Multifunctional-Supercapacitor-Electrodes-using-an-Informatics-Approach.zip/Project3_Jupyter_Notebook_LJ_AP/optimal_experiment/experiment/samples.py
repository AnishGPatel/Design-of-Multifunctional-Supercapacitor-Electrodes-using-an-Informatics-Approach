#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  2 14:18:10 2017

@author: rarroyave
"""


from skopt.space import check_dimension
from skopt.space import Categorical
from skopt.space import space

from random import choice
from string import ascii_uppercase

import operator
import numpy as np

class Sample(dict):
    
    def __init__(self,*args):
        dict.__init__(self,args)
        self.__setitem__('features',{})
        #self.__setitem__('measured',False)
        #self.__setitem__('predicted',False)
        self.__setitem__('observables',{})
        
        self.make_id()
    
    def make_id(self):
        self.__setitem__('id',''.join(choice(ascii_uppercase) for i in range(12)))


    def add_feature(self,key,value):
        self['features'].__setitem__(key,value)
        #self.make_lists()
        
    def make_lists(self,features=None):
        if features == None:
           self.feature_keys_list=sorted(self['features'])
           #print(sorted(self['features'])
           #print(self.feature_keys_list)
                 
           self.feature_values_list=[self['features'][k] for k in self.feature_keys_list]
           #print(self.feature_values_list)
        else:
            self.feature_keys_list=[]
            self.feature_values_list=[]
            for k in sorted(self['features']):
                if k in features:
                    self.feature_keys_list.append(k)
                    self.feature_values_list.append(self['features'][k])            
                    
    def add_observable(self,key):
        self['observables'].__setitem__(key,{})
        self['observables'][key]['name']=key
        self['observables'][key]['value']=None
        self['observables'][key]['measured']=False
        self['observables'][key]['to_measure']=False
        #self['observables'][key]['predicted']=True
        
                
    def measure_observable(self,key,value,std=0.):
        self['observables'][key]['value']=value
        self['observables'][key]['std']=std
        self['observables'][key]['measured']=True
        self['observables'][key]['to_measure']=False
        #self['observables'][key]['predicted']=False
                
    def predict_observable(self,key,value,std=0.):
        self['observables'][key]['value']=value
        self['observables'][key]['std']=std
        self['observables'][key]['measured']=False
        #self['observables'][key]['predicted']=True    

        
class Experimental_Space(dict):
      def __init__(self,*args):
        dict.__init__(self,args)
        self.__setitem__('features',[])
        self.__setitem__('samples',[])
        self['dimensions'] = None
        self['features_list']=[]
        self['space'] = None
        self.sorted = False
        
      def add_feature(self,key,dimension):
        #* `dimension`:
        #Search space Dimension.
        #Each search dimension can be defined either as
        #- a `(upper_bound, lower_bound)` tuple (for `Real` or `Integer`
        #  dimensions),
        #- a `(upper_bound, lower_bound, "prior")` tuple (for `Real`
        #  dimensions),
        #- as a list of categories (for `Categorical` dimensions), or
        #- an instance of a `Dimension` object (`Real`, `Integer` or
        #  `Categorical`).
        feature={}
        
        feature['name']=key
        feature['dimension']=dimension
        feature['use']=True
        self['features'].append(feature)
        #print(self['features'])
        self['features'].sort(key=operator.itemgetter('name'))
        self.set_dimensions()
        


      def add_sample(self,sample):
            self['samples'].append(sample)
            
      
      def sort_samples(self):
          self['samples'].sort(key=operator.itemgetter('id'))
          self.sorted=True
          
      def get_measured_samples(self,observable):
          keyValList=[True]
          measured_list = [elem for elem in filter(lambda x:x['observables'][observable]['measured'] in keyValList,self['samples'])]  
          self['measured_samples'] = measured_list
          return measured_list
    
      def get_unmeasured_samples(self,observable):
          keyValList=[False]
          unmeasured_list = [elem for elem in filter(lambda x:x['observables'][observable]['measured'] in keyValList,self['samples'])]  
          self['unmeasured_samples'] = unmeasured_list
          return unmeasured_list
      
      def get_samples_to_measure(self,observable):
          keyValList=[True]
          samples_to_measure_list = [elem for elem in filter(lambda x:x['observables'][observable]['to_measure'] in keyValList,self['samples'])]  
          self['samples_to_measure'] = samples_to_measure_list
          return [s['id'] for s in samples_to_measure_list]  
        
      def make_lists(self,observable=None,features=None):
        if not self.sorted:  
           self.sort_samples()
        if observable != None:
           self.get_measured_samples(observable)
           self.get_unmeasured_samples(observable) 
           self.get_samples_to_measure(observable)           
            
      def set_x_m(self):      
          self['x_m']=[]
          for s in self['measured_samples']:
               s.make_lists(features=self['features_list']) 
               self['x_m'].append(s.feature_values_list) 
      def set_x_um(self):      
          self['x_um']=[]
          for s in self['unmeasured_samples']:
               s.make_lists(features=self['features_list']) 
               self['x_um'].append(s.feature_values_list)       
            
      def set_xt(self):
          self['x_mt']=[]
          if self['x_m'] == None:
             self.set_x_m() 
          if isinstance(self['space'],space.Space):     
             self['x_mt']=self['space'].transform(self['x_m'])  
          else:
             self.set_dimensions()
             self.set_space()
             self['x_mt']=self['space'].transform(self['x_m'])  
          if self['x_um'] == []:
             return
          self['x_umt']=[]
          if self['x_um'] == None:
             self.set_x_um() 
          if isinstance(self['space'],space.Space):     
             self['x_umt']=self['space'].transform(self['x_um'])  
          #else:
          #   self.set_dimensions()
          #   self.set_space()
          #   self['x_umt']=self['space'].transform(self['x_um'])         
               
      def set_dimensions(self):
          keyValList=[True]
          self['dimensions']=[elem['dimension'] for elem in filter(lambda x:x['use'] in keyValList,self['features'])]
          #print(self['dimensions'])
          self['features_list']=[elem['name'] for elem in filter(lambda x:x['use'] in keyValList,self['features'])]
          self['features_list'].sort()  
          #print(self['features_list'])
        
      def transform_dimensions(self):
          dim_types = [space.check_dimension(d) for d in self['dimensions']]       
          is_cat = all([isinstance(check_dimension(d), Categorical) for d in dim_types])
          
          if is_cat:
             transformed_dims = [check_dimension(d,
                                      transform="identity") for d in self['dimensions']]
          else:
             transformed_dims = []
             for dim_type, dim in zip(dim_types, self['dimensions']):
                 if isinstance(dim_type, Categorical):
                    transformed_dims.append(check_dimension(dim, transform="onehot"))
                    # To make sure that GP operates in the [0, 1] space
                 else:
                     transformed_dims.append(check_dimension(dim, transform="normalize")) 
                        
          self['dimensions']=transformed_dims              
            

  
      def set_space(self):
          if self['dimensions'] != None:  
             self['space']=space.Space(self['dimensions'])
           
      def update(self,feature_list=None,observable=None):
             if feature_list != None:     
                for feature in self['features']:
                    if feature['name'] in feature_list:
                       feature['use'] = True 
                    else:
                       feature['use'] = False  
             self.set_dimensions()
             self.transform_dimensions()
             self.set_space()
             self.make_lists(observable=observable)
             self.set_x_m()
             self.set_x_um()
             try:
                 self.set_xt()
             except:
                 pass
             
      def find_sample_by_id(self,sample_id):
           for i, dic in enumerate(self['samples']):
               if dic['id'] == sample_id:
                  return i
           return -1   
           
      def get_list_of_feature_lists_by_ids(self,sample_ids):
          x=[]
          for sample_id in sample_ids:
              index = self.find_sample_by_id(sample_id)
              self['samples'][index].make_lists(features=self['features_list']) 
              x.append(self['samples'][index].feature_values_list)
          return x
               
      def measure_by_id(self,observable,sample_ids,values):
          for sample_id,value in zip(sample_ids,values):
            si_index = self.find_sample_by_id(sample_id)
            self['samples'][si_index].measure_observable(observable,value,std=0.)
          self.update(observable=observable)
          
      def match_features(self,features,rtol=1e-4):
           for i in np.arange(len(self['samples'])):
               self['samples'][i].make_lists(features=self['features_list'])
               a=features
               b=self['samples'][i].feature_values_list
               if all(np.isclose(a,b,rtol)):
                   return i
           return -1       
