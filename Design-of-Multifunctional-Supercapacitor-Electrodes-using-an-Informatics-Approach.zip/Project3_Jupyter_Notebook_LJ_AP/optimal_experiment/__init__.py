#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 12 11:21:31 2017

@author: rarroyave

optimal_experiment is a library that uses skopt to implement several classes
and methods suitable for optimal experimental design.



"""

__version__ = "0.1"


